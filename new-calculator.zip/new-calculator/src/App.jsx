import { useState, useEffect } from "react";

function calculate(a, b, op) {
  switch (op) {
    case "+": return a + b;
    case "−": return a - b;
    case "×": return a * b;
    case "÷": return b === 0 ? "Error" : a / b;
    default: return b;
  }
}

function format(n) {
  if (n === "Error") return n;
  return String(parseFloat(Number(n).toPrecision(12)));
}

export default function App() {
  const [display, setDisplay] = useState("0");
  const [prev, setPrev] = useState(null);
  const [op, setOp] = useState(null);
  const [waiting, setWaiting] = useState(false);

  const inputDigit = (d) => {
    if (display === "Error" || waiting) {
      setDisplay(d);
      setWaiting(false);
    } else {
      setDisplay(display === "0" ? d : display + d);
    }
  };

  const inputDot = () => {
    if (display === "Error" || waiting) {
      setDisplay("0.");
      setWaiting(false);
      return;
    }
    if (!display.includes(".")) setDisplay(display + ".");
  };

  const clear = () => {
    setDisplay("0");
    setPrev(null);
    setOp(null);
    setWaiting(false);
  };

  const toggleSign = () => {
    if (display !== "0" && display !== "Error")
      setDisplay(display.startsWith("-") ? display.slice(1) : "-" + display);
  };

  const percent = () => {
    if (display !== "Error") setDisplay(format(parseFloat(display) / 100));
  };

  const chooseOp = (nextOp) => {
    if (display === "Error") return;
    const current = parseFloat(display);
    if (prev !== null && op && !waiting) {
      const result = format(calculate(prev, current, op));
      setDisplay(result);
      setPrev(result === "Error" ? null : parseFloat(result));
    } else {
      setPrev(current);
    }
    setOp(nextOp);
    setWaiting(true);
  };

  const equals = () => {
    if (op === null || prev === null || waiting) return;
    setDisplay(format(calculate(prev, parseFloat(display), op)));
    setPrev(null);
    setOp(null);
    setWaiting(true);
  };

  // Keyboard support
  useEffect(() => {
    const onKey = (e) => {
      const k = e.key;
      if (/^[0-9]$/.test(k)) inputDigit(k);
      else if (k === ".") inputDot();
      else if (k === "+") chooseOp("+");
      else if (k === "-") chooseOp("−");
      else if (k === "*") chooseOp("×");
      else if (k === "/") { e.preventDefault(); chooseOp("÷"); }
      else if (k === "Enter" || k === "=") { e.preventDefault(); equals(); }
      else if (k === "Escape") clear();
      else if (k === "Backspace" && !waiting && display !== "Error")
        setDisplay(display.length > 1 ? display.slice(0, -1) : "0");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return (
    <div className="calc">
      <div className="display">
        <div className="expr">{prev !== null && op ? `${format(prev)} ${op}` : ""}</div>
        <div className="value">{display}</div>
      </div>
      <div className="keys">
        <button className="fn" onClick={clear}>AC</button>
        <button className="fn" onClick={toggleSign}>±</button>
        <button className="fn" onClick={percent}>%</button>
        <button className="op" onClick={() => chooseOp("÷")}>÷</button>

        {["7", "8", "9"].map((d) => <button key={d} onClick={() => inputDigit(d)}>{d}</button>)}
        <button className="op" onClick={() => chooseOp("×")}>×</button>

        {["4", "5", "6"].map((d) => <button key={d} onClick={() => inputDigit(d)}>{d}</button>)}
        <button className="op" onClick={() => chooseOp("−")}>−</button>

        {["1", "2", "3"].map((d) => <button key={d} onClick={() => inputDigit(d)}>{d}</button>)}
        <button className="op" onClick={() => chooseOp("+")}>+</button>

        <button className="zero" onClick={() => inputDigit("0")}>0</button>
        <button onClick={inputDot}>.</button>
        <button className="op" onClick={equals}>=</button>
      </div>
    </div>
  );
}
